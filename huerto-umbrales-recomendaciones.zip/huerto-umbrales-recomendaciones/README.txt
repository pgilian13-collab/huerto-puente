CAMBIOS: UMBRALES, RECOMENDACIONES Y ENFOQUE VISUAL
=====================================================
Archivos modificados del frontend monolitico (frontend/)


CONTENIDO:
- frontend/index.html
- frontend/js/app.js
- frontend/css/styles.css


================================================================================
frontend/index.html
================================================================================

a) Logo UNHEVAL corregido:
   URL cambiada de wp-content a portal/public:
   src="https://www.unheval.edu.pe/portal/public/imagenes/unh/logounh-324x84-1-300x78.png"

b) Eliminada fuente Inter (solo se usa JetBrains Mono)

c) Canvas de particulas en el fondo:
   Dentro de .stars-container:
   <canvas id="particleCanvas"></canvas>

d) Selector de plantas en modal de configuracion:
   - Input de busqueda con icono lupa
   - Dropdown dinamico con plantas filtradas
   - Badge de planta seleccionada con boton X

e) Seccion de recomendaciones en modal:
   Div "plant-recommendations" con id="plantRecommendations"

f) Botones de refresh en historico:
   Boton id="btnRefreshHistorico" + label "Auto 10s"

g) Modal header con titulo dinamico:
   h3 con id="configModalTitle" para mostrar INV/MAC actual


================================================================================
frontend/js/app.js
================================================================================

CONFIGURACION DE UMBRALES POR MACETA (ya NO es global):
  getConfigKey()      → "huerto_config_inv{N}_mac{M}"
  getPlantaKey()      → "huerto_planta_inv{N}_mac{M}"
  loadConfigForCurrentMaceta() → carga config de la maceta actual
  Cada maceta tiene sus propios umbrales y planta en localStorage

SELECTOR DE PLANTAS:
  CATALOGO_PLANTAS    → Array con 71 plantas (fallback si Supabase no responde)
  initPlantSelector() → inicializa eventos del buscador
  renderPlantDropdown(query) → filtra por nombre (normaliza tildes)
  seleccionarPlanta(id) → rellena inputs con valores de la planta
  cargarCatalogoPlantas() → carga desde Supabase con fallback al array

RECOMENDACIONES DE PLANTAS:
  showRecommendations() → escanea macetas del invernadero
  Busca plantas con rango de temperatura similar (overlap > 30%)
  Muestra top 5 con % de compatibilidad
  Click en recomendacion la selecciona directamente

SKELETON LOADING:
  setSkeletonActive(true/false) → activa/desactiva shimmer en cards

TOOLTIPS EN CARDS:
  initTooltips() → crea tooltips con rango normal y valor actual
  getThreshold(key, fallback) → lee umbrales de la maceta actual
  Colores: verde=normal, naranja=cerca del limite, rojo=fuera de rango

TRANSICIONES ENTRE TABS:
  selectInvernadero() tiene animacion fade-out/fade-in (250ms)
  selectMaceta() tambien tiene transicion

CHART:
  Font del legend cambiado de 'Inter' a 'JetBrains Mono'


================================================================================
frontend/css/styles.css
================================================================================

VARIABLES CSS:
  --bg-panel: #111
  --font-mono: 'JetBrains Mono', monospace

SKELETON LOADING:
  Clase .skeleton con animacion shimmer
  @keyframes skeletonShimmer

TOOLTIP EN CARDS:
  .sensor-tooltip (estilo brutalist)
  .sensor-tooltip-row, .sensor-tooltip-label, .sensor-tooltip-val
  Colores .warn (naranja) y .crit (rojo)

TRANSICION TABS:
  .main-content con transition de opacity y transform
  .tab-exit para fade-out

PARTICULAS:
  #particleCanvas posicion absolute dentro de stars-container

RECOMENDACIONES:
  .plant-recommendations, .plant-rec-header, .plant-rec-list
  .plant-rec-item con hover
  .plant-rec-match.high (verde) y .plant-rec-match.med (naranja)

MODAL:
  @keyframes scanLine para barra superior animada
  @keyframes modalIn para animacion de entrada
  .modal-overlay.active .modal-box con animacion

SENSOR CARDS:
  cursor: pointer en .sensor-card
  .sensor-card:active para feedback al click

RESPONSIVE:
  .alert-buttons: 5-col -> 3-col (640px) -> 2-col (400px)
  .modal-box: max-width 100% en movil

CSS MUERTO ELIMINADO (~347 lineas):
  .section-title, corner brackets, scan line, rivets
  .card-icon.ph duplicado, .bottom-grid, .macetas-grid
  Bloque .header duplicado (~115 lineas)
