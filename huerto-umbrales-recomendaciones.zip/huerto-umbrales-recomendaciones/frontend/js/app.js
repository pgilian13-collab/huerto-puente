/**
 * APP PRINCIPAL - HUERTO UNIVERSITARIO UNHEVAL
 * ==============================================
 * 5 Invernaderos x 4 Macetas x 4 Sensores = 100 Sensores
 * 5 Invernaderos x (4 Macetas x 3 Actuadores + 1 Buzzer) = 65 Actuadores
 */

let currentInv = 0;
let currentMaceta = 1;
let chart = null;
let pollTimer = null;
let realtimeSub = null;
let vistaTabla = false;
let historicoTimer = null;
let plantaSeleccionadaId = null;
let CATALOGO_PLANTAS = [];

// ============================================================
// CATALOGO DE PLANTAS - Fetch desde Supabase
// ============================================================

async function cargarCatalogoPlantas() {
    try {
        const data = await SupabaseClient.query('catalogo_plantas', 'select=*&order=id');
        if (data && data.length > 0) {
            CATALOGO_PLANTAS = data;
            console.log(`[CATALOGO] ${data.length} plantas cargadas desde Supabase`);
        } else {
            console.warn('[CATALOGO] Sin datos de Supabase, usando respaldo local');
            CATALOGO_PLANTAS = CATALOGO_PLANTAS_FALLBACK;
        }
    } catch (e) {
        console.error('[CATALOGO] Error:', e);
        CATALOGO_PLANTAS = CATALOGO_PLANTAS_FALLBACK;
    }
}

const CATALOGO_PLANTAS_FALLBACK = [
    {id:1,nombre:"Arroz",temp_min:15,temp_max:35,hum_suelo_min:25,hum_suelo_max:79,hum_ambiente_min:46,hum_ambiente_max:74,ph_min:4.8,ph_max:7.7},
    {id:2,nombre:"Trigo",temp_min:19.3,temp_max:29.7,hum_suelo_min:47,hum_suelo_max:82,hum_ambiente_min:58,hum_ambiente_max:93,ph_min:5.0,ph_max:6.9},
    {id:3,nombre:"Maiz",temp_min:16,temp_max:32.6,hum_suelo_min:38,hum_suelo_max:89,hum_ambiente_min:48,hum_ambiente_max:91,ph_min:5.3,ph_max:7.5},
    {id:4,nombre:"Tomate",temp_min:14,temp_max:38.6,hum_suelo_min:20,hum_suelo_max:75,hum_ambiente_min:40,hum_ambiente_max:94,ph_min:5.5,ph_max:7.6},
    {id:5,nombre:"Papa",temp_min:7.3,temp_max:28.7,hum_suelo_min:23,hum_suelo_max:70,hum_ambiente_min:58,hum_ambiente_max:88,ph_min:4.6,ph_max:7.4},
    {id:6,nombre:"Lechuga",temp_min:7.3,temp_max:31.2,hum_suelo_min:40,hum_suelo_max:84,hum_ambiente_min:42,hum_ambiente_max:85,ph_min:5.7,ph_max:7.2},
    {id:7,nombre:"Pepino",temp_min:5.9,temp_max:36.3,hum_suelo_min:20,hum_suelo_max:68,hum_ambiente_min:46,hum_ambiente_max:80,ph_min:5.4,ph_max:7.1},
    {id:8,nombre:"Zanahoria",temp_min:18,temp_max:28.4,hum_suelo_min:25,hum_suelo_max:73,hum_ambiente_min:59,hum_ambiente_max:93,ph_min:4.6,ph_max:7.0},
    {id:9,nombre:"Cebolla",temp_min:14,temp_max:26.2,hum_suelo_min:36,hum_suelo_max:62,hum_ambiente_min:59,hum_ambiente_max:92,ph_min:5.8,ph_max:7.9},
    {id:10,nombre:"Ajo",temp_min:15.6,temp_max:29.3,hum_suelo_min:41,hum_suelo_max:61,hum_ambiente_min:51,hum_ambiente_max:71,ph_min:5.9,ph_max:7.7},
    {id:11,nombre:"Fresa",temp_min:7.7,temp_max:38.1,hum_suelo_min:30,hum_suelo_max:65,hum_ambiente_min:53,hum_ambiente_max:74,ph_min:4.8,ph_max:6.8},
    {id:12,nombre:"Arandano",temp_min:7.8,temp_max:37.1,hum_suelo_min:42,hum_suelo_max:65,hum_ambiente_min:55,hum_ambiente_max:85,ph_min:4.5,ph_max:5.5},
    {id:13,nombre:"Rosa",temp_min:9.6,temp_max:27.8,hum_suelo_min:39,hum_suelo_max:68,hum_ambiente_min:56,hum_ambiente_max:80,ph_min:5.1,ph_max:7.6},
    {id:14,nombre:"Tulipan",temp_min:12.9,temp_max:38.4,hum_suelo_min:45,hum_suelo_max:76,hum_ambiente_min:56,hum_ambiente_max:94,ph_min:5.2,ph_max:7.4},
    {id:15,nombre:"Lavanda",temp_min:11.5,temp_max:33.1,hum_suelo_min:40,hum_suelo_max:81,hum_ambiente_min:42,hum_ambiente_max:91,ph_min:5.4,ph_max:7.8},
    {id:16,nombre:"Albahaca",temp_min:9.4,temp_max:37.1,hum_suelo_min:37,hum_suelo_max:80,hum_ambiente_min:50,hum_ambiente_max:91,ph_min:5.1,ph_max:6.7},
    {id:17,nombre:"Menta",temp_min:14.2,temp_max:38.4,hum_suelo_min:23,hum_suelo_max:68,hum_ambiente_min:41,hum_ambiente_max:82,ph_min:5.2,ph_max:7.7},
    {id:18,nombre:"Cilantro",temp_min:7.1,temp_max:29.8,hum_suelo_min:31,hum_suelo_max:89,hum_ambiente_min:51,hum_ambiente_max:80,ph_min:5.6,ph_max:6.8},
    {id:19,nombre:"Espinaca",temp_min:9.4,temp_max:26.7,hum_suelo_min:28,hum_suelo_max:82,hum_ambiente_min:49,hum_ambiente_max:77,ph_min:4.6,ph_max:6.7},
    {id:20,nombre:"Kale",temp_min:10.5,temp_max:28.4,hum_suelo_min:27,hum_suelo_max:77,hum_ambiente_min:58,hum_ambiente_max:71,ph_min:4.9,ph_max:6.7},
    {id:21,nombre:"Brocoli",temp_min:11.8,temp_max:31.4,hum_suelo_min:49,hum_suelo_max:78,hum_ambiente_min:47,hum_ambiente_max:92,ph_min:5.6,ph_max:7.7},
    {id:22,nombre:"Coliflor",temp_min:16.8,temp_max:37.3,hum_suelo_min:32,hum_suelo_max:73,hum_ambiente_min:42,hum_ambiente_max:90,ph_min:5.8,ph_max:7.5},
    {id:23,nombre:"Repollo",temp_min:8,temp_max:37.9,hum_suelo_min:47,hum_suelo_max:67,hum_ambiente_min:43,hum_ambiente_max:95,ph_min:5.3,ph_max:7.3},
    {id:24,nombre:"Pimiento",temp_min:12.7,temp_max:25.1,hum_suelo_min:39,hum_suelo_max:71,hum_ambiente_min:55,hum_ambiente_max:95,ph_min:5.3,ph_max:7.0},
    {id:25,nombre:"Berenjena",temp_min:13.9,temp_max:32.7,hum_suelo_min:44,hum_suelo_max:83,hum_ambiente_min:52,hum_ambiente_max:84,ph_min:4.7,ph_max:7.8},
    {id:26,nombre:"Calabazon",temp_min:5.7,temp_max:31.3,hum_suelo_min:35,hum_suelo_max:60,hum_ambiente_min:42,hum_ambiente_max:89,ph_min:5.2,ph_max:7.1},
    {id:27,nombre:"Calabaza",temp_min:14.1,temp_max:28.3,hum_suelo_min:37,hum_suelo_max:63,hum_ambiente_min:42,hum_ambiente_max:94,ph_min:5.3,ph_max:7.7},
    {id:28,nombre:"Frijoles",temp_min:7.6,temp_max:26.8,hum_suelo_min:35,hum_suelo_max:61,hum_ambiente_min:54,hum_ambiente_max:91,ph_min:4.9,ph_max:7.2},
    {id:29,nombre:"Guisantes",temp_min:6,temp_max:30.1,hum_suelo_min:26,hum_suelo_max:61,hum_ambiente_min:41,hum_ambiente_max:76,ph_min:4.9,ph_max:7.1},
    {id:30,nombre:"Lentejas",temp_min:19.2,temp_max:39.1,hum_suelo_min:42,hum_suelo_max:86,hum_ambiente_min:56,hum_ambiente_max:81,ph_min:5.1,ph_max:7.2},
    {id:31,nombre:"Garbanzo",temp_min:19.5,temp_max:29.8,hum_suelo_min:28,hum_suelo_max:81,hum_ambiente_min:54,hum_ambiente_max:73,ph_min:4.5,ph_max:7.0},
    {id:32,nombre:"Soja",temp_min:17.1,temp_max:32.8,hum_suelo_min:21,hum_suelo_max:74,hum_ambiente_min:42,hum_ambiente_max:94,ph_min:5.0,ph_max:7.6},
    {id:33,nombre:"Girasol",temp_min:9.6,temp_max:35.5,hum_suelo_min:39,hum_suelo_max:63,hum_ambiente_min:42,hum_ambiente_max:85,ph_min:4.8,ph_max:7.3},
    {id:34,nombre:"Cafe",temp_min:15.3,temp_max:39.6,hum_suelo_min:48,hum_suelo_max:74,hum_ambiente_min:47,hum_ambiente_max:87,ph_min:4.7,ph_max:7.8},
    {id:35,nombre:"Te",temp_min:11.6,temp_max:39.4,hum_suelo_min:49,hum_suelo_max:65,hum_ambiente_min:47,hum_ambiente_max:85,ph_min:5.8,ph_max:7.1},
    {id:36,nombre:"Cacao",temp_min:6.8,temp_max:28.8,hum_suelo_min:47,hum_suelo_max:73,hum_ambiente_min:56,hum_ambiente_max:79,ph_min:5.4,ph_max:7.3},
    {id:37,nombre:"Aguacate",temp_min:12.4,temp_max:32.5,hum_suelo_min:31,hum_suelo_max:72,hum_ambiente_min:59,hum_ambiente_max:73,ph_min:5.5,ph_max:7.9},
    {id:38,nombre:"Mango",temp_min:5.5,temp_max:29.5,hum_suelo_min:20,hum_suelo_max:78,hum_ambiente_min:60,hum_ambiente_max:87,ph_min:5.7,ph_max:7.4},
    {id:39,nombre:"Pina",temp_min:18.6,temp_max:29.3,hum_suelo_min:48,hum_suelo_max:79,hum_ambiente_min:55,hum_ambiente_max:83,ph_min:5.2,ph_max:6.7},
    {id:40,nombre:"Papaya",temp_min:8.9,temp_max:25.6,hum_suelo_min:33,hum_suelo_max:61,hum_ambiente_min:48,hum_ambiente_max:89,ph_min:4.6,ph_max:7.9},
    {id:41,nombre:"Coco",temp_min:14.9,temp_max:34.1,hum_suelo_min:49,hum_suelo_max:71,hum_ambiente_min:42,hum_ambiente_max:83,ph_min:5.3,ph_max:7.4},
    {id:42,nombre:"Limon",temp_min:7.9,temp_max:28.6,hum_suelo_min:23,hum_suelo_max:72,hum_ambiente_min:53,hum_ambiente_max:73,ph_min:4.9,ph_max:6.6},
    {id:43,nombre:"Lima",temp_min:5.7,temp_max:35.9,hum_suelo_min:38,hum_suelo_max:79,hum_ambiente_min:55,hum_ambiente_max:70,ph_min:4.7,ph_max:7.4},
    {id:44,nombre:"Sandia",temp_min:10.8,temp_max:34.5,hum_suelo_min:24,hum_suelo_max:76,hum_ambiente_min:59,hum_ambiente_max:85,ph_min:4.9,ph_max:7.8},
    {id:45,nombre:"Melon",temp_min:9.1,temp_max:34.5,hum_suelo_min:36,hum_suelo_max:88,hum_ambiente_min:47,hum_ambiente_max:80,ph_min:4.7,ph_max:7.0},
    {id:46,nombre:"Rabano",temp_min:17.4,temp_max:33,hum_suelo_min:46,hum_suelo_max:72,hum_ambiente_min:46,hum_ambiente_max:81,ph_min:4.8,ph_max:7.7},
    {id:47,nombre:"Remolacha",temp_min:10.4,temp_max:26.4,hum_suelo_min:42,hum_suelo_max:89,hum_ambiente_min:57,hum_ambiente_max:93,ph_min:4.9,ph_max:6.7},
    {id:48,nombre:"Esparrago",temp_min:9.2,temp_max:37.5,hum_suelo_min:41,hum_suelo_max:87,hum_ambiente_min:44,hum_ambiente_max:79,ph_min:4.8,ph_max:7.8},
    {id:49,nombre:"Alcachofa",temp_min:13.1,temp_max:29.8,hum_suelo_min:41,hum_suelo_max:66,hum_ambiente_min:59,hum_ambiente_max:83,ph_min:5.8,ph_max:6.7},
    {id:50,nombre:"Apio",temp_min:7.1,temp_max:27.8,hum_suelo_min:31,hum_suelo_max:62,hum_ambiente_min:40,hum_ambiente_max:90,ph_min:4.6,ph_max:7.1},
    {id:51,nombre:"Puerro",temp_min:17,temp_max:25.6,hum_suelo_min:29,hum_suelo_max:63,hum_ambiente_min:59,hum_ambiente_max:80,ph_min:5.3,ph_max:7.7},
    {id:52,nombre:"Hinojo",temp_min:6.1,temp_max:33.9,hum_suelo_min:44,hum_suelo_max:61,hum_ambiente_min:41,hum_ambiente_max:86,ph_min:5.1,ph_max:6.7},
    {id:53,nombre:"Perejil",temp_min:19.8,temp_max:35.2,hum_suelo_min:44,hum_suelo_max:63,hum_ambiente_min:58,hum_ambiente_max:92,ph_min:6.0,ph_max:6.8},
    {id:54,nombre:"Tomillo",temp_min:16.6,temp_max:25.2,hum_suelo_min:46,hum_suelo_max:80,hum_ambiente_min:51,hum_ambiente_max:94,ph_min:4.7,ph_max:7.6},
    {id:55,nombre:"Romero",temp_min:8,temp_max:32.7,hum_suelo_min:47,hum_suelo_max:62,hum_ambiente_min:60,hum_ambiente_max:74,ph_min:5.1,ph_max:7.6},
    {id:56,nombre:"Oregano",temp_min:5.1,temp_max:28.4,hum_suelo_min:35,hum_suelo_max:70,hum_ambiente_min:41,hum_ambiente_max:93,ph_min:6.0,ph_max:7.5},
    {id:57,nombre:"Salvia",temp_min:17.2,temp_max:34.7,hum_suelo_min:35,hum_suelo_max:85,hum_ambiente_min:51,hum_ambiente_max:82,ph_min:5.8,ph_max:7.5},
    {id:58,nombre:"Eneldo",temp_min:15.6,temp_max:27.6,hum_suelo_min:44,hum_suelo_max:61,hum_ambiente_min:59,hum_ambiente_max:76,ph_min:5.7,ph_max:7.3},
    {id:59,nombre:"Cebollino",temp_min:15.9,temp_max:35.4,hum_suelo_min:39,hum_suelo_max:84,hum_ambiente_min:50,hum_ambiente_max:81,ph_min:4.9,ph_max:6.9},
    {id:60,nombre:"Calendula",temp_min:16.6,temp_max:30.8,hum_suelo_min:41,hum_suelo_max:68,hum_ambiente_min:53,hum_ambiente_max:95,ph_min:4.8,ph_max:7.0},
    {id:61,nombre:"Dalia",temp_min:6.1,temp_max:39.1,hum_suelo_min:44,hum_suelo_max:64,hum_ambiente_min:54,hum_ambiente_max:82,ph_min:5.5,ph_max:6.8},
    {id:62,nombre:"Girasol ornamental",temp_min:10.4,temp_max:27.1,hum_suelo_min:47,hum_suelo_max:81,hum_ambiente_min:49,hum_ambiente_max:78,ph_min:5.9,ph_max:7.9},
    {id:63,nombre:"Margarita",temp_min:6.7,temp_max:30.1,hum_suelo_min:30,hum_suelo_max:79,hum_ambiente_min:53,hum_ambiente_max:86,ph_min:5.3,ph_max:7.4},
    {id:64,nombre:"Lirio",temp_min:17.9,temp_max:26.7,hum_suelo_min:31,hum_suelo_max:86,hum_ambiente_min:52,hum_ambiente_max:76,ph_min:5.4,ph_max:7.1},
    {id:65,nombre:"Orquidea",temp_min:14.3,temp_max:38.9,hum_suelo_min:23,hum_suelo_max:82,hum_ambiente_min:58,hum_ambiente_max:72,ph_min:4.9,ph_max:7.2},
    {id:66,nombre:"Helecho",temp_min:10,temp_max:38.2,hum_suelo_min:37,hum_suelo_max:84,hum_ambiente_min:41,hum_ambiente_max:73,ph_min:5.7,ph_max:7.9},
    {id:67,nombre:"Cactus",temp_min:6,temp_max:28.9,hum_suelo_min:21,hum_suelo_max:68,hum_ambiente_min:46,hum_ambiente_max:73,ph_min:4.8,ph_max:6.7},
    {id:68,nombre:"Suculenta",temp_min:9.7,temp_max:34.9,hum_suelo_min:34,hum_suelo_max:65,hum_ambiente_min:59,hum_ambiente_max:74,ph_min:5.0,ph_max:7.4},
    {id:69,nombre:"Aloe Vera",temp_min:9.9,temp_max:37.3,hum_suelo_min:36,hum_suelo_max:83,hum_ambiente_min:58,hum_ambiente_max:73,ph_min:5.1,ph_max:7.3},
    {id:70,nombre:"Bambu",temp_min:15.9,temp_max:33.3,hum_suelo_min:29,hum_suelo_max:84,hum_ambiente_min:49,hum_ambiente_max:86,ph_min:5.3,ph_max:7.4},
    {id:71,nombre:"Hibisco",temp_min:5.5,temp_max:26.3,hum_suelo_min:36,hum_suelo_max:85,hum_ambiente_min:54,hum_ambiente_max:82,ph_min:5.0,ph_max:7.9}
];

// ============================================================
// INICIALIZACION
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
    console.log('[APP] Iniciando Huerto Inteligente...');

    const connected = await SupabaseClient.healthCheck();
    const dot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    const liveIndicator = document.getElementById('liveIndicator');

    if (connected) {
        dot.classList.add('online');
        statusText.textContent = 'Conectado';
        liveIndicator.style.display = 'flex';
    } else {
        dot.classList.remove('online');
        statusText.textContent = 'Sin conexion';
        liveIndicator.style.display = 'none';
    }

    initMacetaTabs();
    setSkeletonActive(true);
    await cargarDatos();
    setSkeletonActive(false);
    initTooltips();
    initChart();
    iniciarRealtime();
    iniciarAutoRefreshHistorico();

    pollTimer = setInterval(cargarDatos, CONFIG.POLL_INTERVAL);
    console.log('[APP] Iniciado');

    const loader = document.getElementById('loader');
    loader.classList.add('hidden');
    setTimeout(() => loader.remove(), 500);

    initSensorModals();
    await cargarCatalogoPlantas();
    initPlantSelector();

    const fab = document.getElementById('fabConfig');
    const modal = document.getElementById('configModal');
    const closeBtn = document.getElementById('modalClose');

    if (fab && modal) {
        fab.addEventListener('click', () => {
            modal.classList.add('active');
            showRecommendations();
        });
    }
    if (closeBtn && modal) {
        closeBtn.addEventListener('click', () => {
            modal.classList.remove('active');
        });
    }
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.classList.remove('active');
        });
    }
});

// ============================================================
// PLANT SELECTOR - BUSCADOR DINAMICO
// ============================================================

function initPlantSelector() {
    const searchInput = document.getElementById('plantSearchInput');
    const dropdown = document.getElementById('plantDropdown');
    const list = document.getElementById('plantDropdownList');
    const chevron = document.getElementById('plantChevron');
    const clearBtn = document.getElementById('plantClearBtn');

    if (!searchInput) return;

    renderPlantDropdown('');

    searchInput.addEventListener('focus', () => {
        dropdown.classList.add('active');
        chevron.classList.add('open');
        renderPlantDropdown(searchInput.value);
    });

    searchInput.addEventListener('input', () => {
        renderPlantDropdown(searchInput.value);
        dropdown.classList.add('active');
        chevron.classList.add('open');
    });

    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            searchInput.blur();
            dropdown.classList.remove('active');
            chevron.classList.remove('open');
        }
    });

    document.addEventListener('click', (e) => {
        const wrap = document.getElementById('plantSearchWrap');
        if (wrap && !wrap.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.classList.remove('active');
            chevron.classList.remove('open');
        }
    });

    if (clearBtn) {
        clearBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            plantaSeleccionadaId = null;
            document.getElementById('plantSelectedBadge').style.display = 'none';
            searchInput.value = '';
            localStorage.removeItem(getPlantaKey());
        });
    }
}

function renderPlantDropdown(query) {
    const list = document.getElementById('plantDropdownList');
    if (!list) return;

    const q = query.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const filtered = CATALOGO_PLANTAS.filter(p =>
        p.nombre.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(q)
    );

    if (filtered.length === 0) {
        list.innerHTML = '<div class="plant-dropdown-empty">No se encontraron plantas</div>';
        return;
    }

    list.innerHTML = filtered.map(p => `
        <div class="plant-dropdown-item" data-id="${p.id}" onclick="seleccionarPlanta(${p.id})">
            <span class="material-icons-round plant-item-icon">eco</span>
            <span class="plant-item-name">${p.nombre}</span>
            <span class="plant-item-range">${p.temp_min}-${p.temp_max}°C | pH ${p.ph_min}-${p.ph_max}</span>
        </div>
    `).join('');
}

function seleccionarPlanta(id) {
    const planta = CATALOGO_PLANTAS.find(p => p.id === id);
    if (!planta) return;

    plantaSeleccionadaId = id;

    document.getElementById('cfg-temp-min').value = planta.temp_min;
    document.getElementById('cfg-temp-max').value = planta.temp_max;
    document.getElementById('cfg-hum-min').value = planta.hum_suelo_min;
    document.getElementById('cfg-hum-max').value = planta.hum_suelo_max;
    document.getElementById('cfg-ph-min').value = planta.ph_min;
    document.getElementById('cfg-ph-max').value = planta.ph_max;

    document.getElementById('plantSelectedName').textContent = planta.nombre;
    document.getElementById('plantSelectedBadge').style.display = 'flex';

    const dropdown = document.getElementById('plantDropdown');
    const chevron = document.getElementById('plantChevron');
    const searchInput = document.getElementById('plantSearchInput');
    dropdown.classList.remove('active');
    chevron.classList.remove('open');
    searchInput.value = '';
    searchInput.blur();

    localStorage.setItem('huerto_planta_seleccionada', JSON.stringify({
        id: planta.id,
        nombre: planta.nombre
    }));
}

// ============================================================
// MACETA TABS
// ============================================================

function initMacetaTabs() {
    const container = document.getElementById('macetaTabs');
    if (!container) return;

    container.innerHTML = '';
    for (let m = 1; m <= CONFIG.MACETAS_POR_INV; m++) {
        const btn = document.createElement('button');
        btn.className = `maceta-tab ${m === currentMaceta ? 'active' : ''}`;
        btn.setAttribute('data-maceta', m);
        btn.textContent = `MAC-${String(m).padStart(2, '0')}`;
        btn.onclick = () => selectMaceta(m);
        container.appendChild(btn);
    }
}

function selectMaceta(macetaNum) {
    currentMaceta = macetaNum;

    document.querySelectorAll('.maceta-tab').forEach((tab) => {
        const tabNum = parseInt(tab.getAttribute('data-maceta'));
        tab.classList.toggle('active', tabNum === macetaNum);
    });

    loadConfigForCurrentMaceta();
    showRecommendations();
    cargarDatos();
    cargarHistorico();
    iniciarRealtime();
}

// ============================================================
// REALTIME
// ============================================================

function iniciarRealtime() {
    if (realtimeSub) SupabaseClient.unsubscribe();

    const dispositivoId = currentInv + 1;

    realtimeSub = SupabaseClient.subscribeLecturas(currentInv, (lectura) => {
        const sid = lectura.sensor_id;
        const val = parseFloat(lectura.valor_lectura);

        const ids = CONFIG.getSensoresMaceta(dispositivoId, currentMaceta);
        const expectedIds = [ids.temp, ids.hum_amb, ids.hum_suelo, ids.ph];

        if (!expectedIds.includes(sid)) return;

        if (sid === ids.temp) {
            document.getElementById('temp').textContent = val.toFixed(1);
            setSensorStatus('tempStatus', getTempStatus(val));
        } else if (sid === ids.hum_amb) {
            document.getElementById('humAmb').textContent = val.toFixed(1);
            setSensorStatus('humAmbStatus', getHumAmbStatus(val));
        } else if (sid === ids.hum_suelo) {
            document.getElementById('humSuelo').textContent = val.toFixed(0);
            setSensorStatus('humSueloStatus', getHumSueloStatus(val));
        } else if (sid === ids.ph) {
            document.getElementById('ph').textContent = val.toFixed(1);
            setSensorStatus('phStatus', getPhStatus(val));
        }

        console.log(`[RT] Sensor ${sid} (MAC${currentMaceta}) -> ${val}`);
    });

    SupabaseClient.subscribeActuadores(currentInv, (act) => {
        updateActuadorUI(act);
        console.log(`[RT] ${act.nombre} -> ${act.estado_actual}`);
    });
}

// ============================================================
// CARGAR DATOS
// ============================================================

async function cargarDatos() {
    try {
        const dispositivoId = currentInv + 1;
        const ids = CONFIG.getSensoresMaceta(dispositivoId, currentMaceta);

        const lecturas = await SupabaseClient.query('monitoreo_lecturas',
            `sensor_id=in.(${ids.temp},${ids.hum_amb},${ids.hum_suelo},${ids.ph})&order=fecha_hora.desc&limit=16`
        );

        if (lecturas && lecturas.length > 0) {
            const data = {};
            lecturas.forEach(l => {
                if (l.sensor_id === ids.temp && data.temp === undefined) data.temp = l.valor_lectura;
                if (l.sensor_id === ids.hum_amb && data.humAmb === undefined) data.humAmb = l.valor_lectura;
                if (l.sensor_id === ids.hum_suelo && data.humSuelo === undefined) data.humSuelo = l.valor_lectura;
                if (l.sensor_id === ids.ph && data.ph === undefined) data.ph = l.valor_lectura;
            });
            actualizarSensores(data);
            initTooltips();
        } else {
            resetSensores();
        }

        const actuadores = await SupabaseClient.getActuadores(currentInv);
        if (actuadores) {
            actualizarActuadores(actuadores);
        } else {
            resetActuadores();
        }
    } catch (e) {
        console.error('[DATOS] Error:', e);
    }
}

// ============================================================
// UI SENSORES
// ============================================================

function resetSensores() {
    ['temp', 'humAmb', 'humSuelo', 'ph'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = '-';
    });
    ['tempStatus', 'humAmbStatus', 'humSueloStatus', 'phStatus'].forEach(id => {
        setSensorStatus(id, '');
    });
}

function resetActuadores() {
    ['bomba', 'ventilador', 'pulverizador', 'buzzer'].forEach(nombre => {
        const btn = document.getElementById(`btn-${nombre}`);
        const card = document.getElementById(`act-${nombre}`);
        const led = document.getElementById(`${nombre}-led`);
        const fill = document.getElementById(`${nombre}-fill`);
        const lastEl = document.getElementById(`${nombre}-last`);
        if (btn) {
            btn.innerHTML = `<span class="material-icons-round">power_settings_new</span><span class="btn-label">OFF</span>`;
            btn.className = 'brutalist-btn off';
        }
        if (card) card.classList.remove('active');
        if (led) led.classList.remove('active');
        if (fill) fill.style.width = '0%';
        if (lastEl) lastEl.textContent = '--:--';
    });
}

function actualizarSensores(data) {
    if (data.temp !== undefined) {
        document.getElementById('temp').textContent = data.temp.toFixed(1);
        setSensorStatus('tempStatus', getTempStatus(data.temp));
    }
    if (data.humAmb !== undefined) {
        document.getElementById('humAmb').textContent = data.humAmb.toFixed(1);
        setSensorStatus('humAmbStatus', getHumAmbStatus(data.humAmb));
    }
    if (data.humSuelo !== undefined) {
        document.getElementById('humSuelo').textContent = data.humSuelo.toFixed(0);
        setSensorStatus('humSueloStatus', getHumSueloStatus(data.humSuelo));
    }
    if (data.ph !== undefined) {
        document.getElementById('ph').textContent = data.ph.toFixed(1);
        setSensorStatus('phStatus', getPhStatus(data.ph));
    }
}

function getTempStatus(val) {
    if (val > 35 || val < 10) return 'critical';
    if (val > 30 || val < 15) return 'warning';
    return '';
}

function getHumAmbStatus(val) {
    if (val > 85 || val < 20) return 'critical';
    if (val > 75 || val < 30) return 'warning';
    return '';
}

function getHumSueloStatus(val) {
    if (val < 30) return 'critical';
    if (val < 40 || val > 80) return 'warning';
    return '';
}

function getPhStatus(val) {
    if (val < 4.5 || val > 9.0) return 'critical';
    if (val < 5.5 || val > 7.5) return 'warning';
    return '';
}

function setSensorStatus(elementId, status) {
    const el = document.getElementById(elementId);
    if (el) el.className = 'card-status ' + status;
}

// ============================================================
// UI ACTUADORES
// ============================================================

function actualizarActuadores(actuadores) {
    actuadores.forEach(act => {
        updateActuadorUI(act);
    });
}

function updateActuadorUI(act) {
    const btn = document.getElementById(`btn-${act.nombre}`);
    const card = document.getElementById(`act-${act.nombre}`);
    if (!btn) return;

    const isOn = act.estado_actual === 'ON';
    const now = new Date().toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });

    btn.innerHTML = `<span class="material-icons-round">power_settings_new</span><span class="btn-label">${isOn ? 'ON' : 'OFF'}</span>`;
    btn.className = `brutalist-btn ${isOn ? 'on' : 'off'}`;
    if (card) card.classList.toggle('active', isOn);

    const led = document.getElementById(`${act.nombre}-led`);
    const fill = document.getElementById(`${act.nombre}-fill`);
    const lastEl = document.getElementById(`${act.nombre}-last`);
    if (led) led.classList.toggle('active', isOn);
    if (fill) fill.style.width = isOn ? '100%' : '0%';
    if (lastEl && isOn) lastEl.textContent = now;
}

// ============================================================
// TOGGLE ACTUADOR
// ============================================================

async function toggleActuador(nombre, macetaNum) {
    const btn = document.getElementById(`btn-${nombre}`);
    const isOn = btn.classList.contains('on');
    const nuevoEstado = isOn ? 'OFF' : 'ON';
    const dispositivoId = currentInv + 1;

    let actuadorId, pin;
    if (nombre === 'buzzer') {
        actuadorId = CONFIG.getBuzzerId(dispositivoId);
        pin = 26;
    } else {
        actuadorId = CONFIG.getActuadorId(dispositivoId, macetaNum, nombre === 'bomba' ? 1 : nombre === 'ventilador' ? 2 : 3);
        pin = CONFIG.PIN_MAP[macetaNum][nombre];
    }

    const ok = await SupabaseClient.enviarComando(actuadorId, nombre, pin, nuevoEstado, dispositivoId);

    if (ok) {
        const now = new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Lima' });

        btn.innerHTML = `<span class="material-icons-round">power_settings_new</span><span class="btn-label">${nuevoEstado}</span>`;
        btn.className = `brutalist-btn ${nuevoEstado === 'ON' ? 'on' : 'off'}`;
        document.getElementById(`act-${nombre}`).classList.toggle('active', nuevoEstado === 'ON');

        const led = document.getElementById(`${nombre}-led`);
        const fill = document.getElementById(`${nombre}-fill`);
        const lastEl = document.getElementById(`${nombre}-last`);
        if (led) led.classList.toggle('active', nuevoEstado === 'ON');
        if (fill) fill.style.width = nuevoEstado === 'ON' ? '100%' : '0%';
        if (lastEl && nuevoEstado === 'ON') lastEl.textContent = now;
    }
}

// ============================================================
// GUARDAR CONFIGURACION
// ============================================================

function getConfigKey() {
    return `huerto_config_inv${currentInv + 1}_mac${currentMaceta}`;
}

function getPlantaKey() {
    return `huerto_planta_inv${currentInv + 1}_mac${currentMaceta}`;
}

async function guardarConfig() {
    const config = {
        temp_min: parseFloat(document.getElementById('cfg-temp-min').value),
        temp_max: parseFloat(document.getElementById('cfg-temp-max').value),
        hum_suelo_min: parseFloat(document.getElementById('cfg-hum-min').value),
        hum_suelo_max: parseFloat(document.getElementById('cfg-hum-max').value),
        ph_min: parseFloat(document.getElementById('cfg-ph-min').value),
        ph_max: parseFloat(document.getElementById('cfg-ph-max').value),
        planta_id: plantaSeleccionadaId,
    };
    localStorage.setItem(getConfigKey(), JSON.stringify(config));

    if (plantaSeleccionadaId) {
        const planta = CATALOGO_PLANTAS.find(p => p.id === plantaSeleccionadaId);
        if (planta) {
            localStorage.setItem(getPlantaKey(), JSON.stringify({
                id: plantaSeleccionadaId,
                nombre: planta.nombre
            }));
        }
    } else {
        localStorage.removeItem(getPlantaKey());
    }

    const btn = document.querySelector('.btn-save');
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons-round">check</span> Guardado';
    btn.style.background = '#16a34a';
    setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.style.background = '';
    }, 2000);
}

// ============================================================
// CHART
// ============================================================

function initChart() {
    const ctx = document.getElementById('chartHistorico').getContext('2d');

    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Temperatura (°C)',
                    data: [],
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 2,
                    borderWidth: 2,
                },
                {
                    label: 'Humedad Suelo (%)',
                    data: [],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 2,
                    borderWidth: 2,
                },
                {
                    label: 'Humedad Ambiente (%)',
                    data: [],
                    borderColor: '#06b6d4',
                    backgroundColor: 'rgba(6, 182, 212, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 2,
                    borderWidth: 2,
                },
                {
                    label: 'pH',
                    data: [],
                    borderColor: '#a855f7',
                    backgroundColor: 'rgba(168, 85, 247, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 2,
                    borderWidth: 2,
                    yAxisID: 'y1',
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { intersect: false, mode: 'index' },
            plugins: {
                legend: {
                    labels: { color: '#94a3b8', font: { family: 'JetBrains Mono', size: 11 }, usePointStyle: true, pointStyle: 'circle' },
                },
                tooltip: {
                    backgroundColor: '#1e293b',
                    titleColor: '#f1f5f9',
                    bodyColor: '#94a3b8',
                    borderColor: '#334155',
                    borderWidth: 1,
                    padding: 10,
                    cornerRadius: 8,
                },
            },
            scales: {
                x: { ticks: { color: '#64748b', font: { size: 10 } }, grid: { color: 'rgba(51,65,85,0.5)' } },
                y: { ticks: { color: '#64748b', font: { size: 10 } }, grid: { color: 'rgba(51,65,85,0.5)' }, min: 0, max: 100 },
                y1: {
                    position: 'right',
                    ticks: { color: '#a855f7', font: { size: 10 } },
                    grid: { drawOnChartArea: false },
                    min: 0, max: 14,
                },
            },
        },
    });

    cargarHistorico();
}

async function cargarHistorico() {
    try {
        const dispositivoId = currentInv + 1;
        const ids = CONFIG.getSensoresMaceta(dispositivoId, currentMaceta);

        const lecturas = await SupabaseClient.query('monitoreo_lecturas',
            `sensor_id=in.(${ids.temp},${ids.hum_amb},${ids.hum_suelo},${ids.ph})&order=fecha_hora.desc&limit=${CONFIG.CHART_POINTS}`
        );
        if (!lecturas || lecturas.length === 0) {
            if (chart) {
                chart.data.labels = [];
                chart.data.datasets.forEach(d => { d.data = []; });
                chart.update();
            }
            const tbody = document.getElementById('dataTableBody');
            if (tbody) tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#64748b;">Sin datos</td></tr>';
            return;
        }

        const temporal = {};
        lecturas.forEach(l => {
            const fecha = new Date(l.fecha_hora);
            const ts = fecha.toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', timeZone: 'America/Lima' });
            const tsFull = fecha.toLocaleString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Lima' });
            if (!temporal[ts]) temporal[ts] = { full: tsFull };
            if (l.sensor_id === ids.temp) temporal[ts].temp = l.valor_lectura;
            if (l.sensor_id === ids.hum_amb) temporal[ts].humAmb = l.valor_lectura;
            if (l.sensor_id === ids.hum_suelo) temporal[ts].humSuelo = l.valor_lectura;
            if (l.sensor_id === ids.ph) temporal[ts].ph = l.valor_lectura;
        });

        const labels = Object.keys(temporal).reverse();
        if (chart) {
            chart.data.labels = labels;
            chart.data.datasets[0].data = labels.map(k => temporal[k].temp || null);
            chart.data.datasets[1].data = labels.map(k => temporal[k].humSuelo || null);
            chart.data.datasets[2].data = labels.map(k => temporal[k].humAmb || null);
            chart.data.datasets[3].data = labels.map(k => temporal[k].ph || null);
            chart.update();
        }

        const tbody = document.getElementById('dataTableBody');
        if (tbody) {
            tbody.innerHTML = '';
            labels.forEach(k => {
                const d = temporal[k];
                tbody.innerHTML += `<tr>
                    <td>${d.full || k}</td>
                    <td>${d.temp !== undefined ? d.temp.toFixed(1) : '-'}</td>
                    <td>${d.humAmb !== undefined ? d.humAmb.toFixed(1) : '-'}</td>
                    <td>${d.humSuelo !== undefined ? d.humSuelo.toFixed(0) : '-'}</td>
                    <td>${d.ph !== undefined ? d.ph.toFixed(2) : '-'}</td>
                </tr>`;
            });
        }

        const label = document.getElementById('autoRefreshLabel');
        if (label) {
            const now = new Date().toLocaleTimeString('es-PE', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Lima' });
            label.textContent = 'Auto 10s | ' + now;
        }
    } catch (e) {
        console.error('[HIST] Error:', e);
    }
}

function iniciarAutoRefreshHistorico() {
    if (historicoTimer) clearInterval(historicoTimer);
    historicoTimer = setInterval(cargarHistorico, 10000);
}

function toggleVistaDatos() {
    vistaTabla = !vistaTabla;
    const chartEl = document.getElementById('chartContainer');
    const tableEl = document.getElementById('dataTableContainer');
    const btn = document.getElementById('btnToggleData');

    if (vistaTabla) {
        chartEl.style.display = 'none';
        tableEl.style.display = 'block';
        btn.innerHTML = '<span class="material-icons-round">show_chart</span><span>Grafico</span>';
    } else {
        chartEl.style.display = 'block';
        tableEl.style.display = 'none';
        btn.innerHTML = '<span class="material-icons-round">table_chart</span><span>Tabla</span>';
    }
}

// ============================================================
// CARGAR CONFIG GUARDADA
// ============================================================

function loadConfigForCurrentMaceta() {
    const title = document.getElementById('configModalTitle');
    if (title) {
        title.textContent = `Config - INV${String(currentInv + 1).padStart(2, '0')} / MAC${String(currentMaceta).padStart(2, '0')}`;
    }

    const key = getConfigKey();
    const saved = localStorage.getItem(key);
    if (saved) {
        const c = JSON.parse(saved);
        document.getElementById('cfg-temp-min').value = c.temp_min;
        document.getElementById('cfg-temp-max').value = c.temp_max;
        document.getElementById('cfg-hum-min').value = c.hum_suelo_min;
        document.getElementById('cfg-hum-max').value = c.hum_suelo_max;
        if (c.ph_min !== undefined) document.getElementById('cfg-ph-min').value = c.ph_min;
        if (c.ph_max !== undefined) document.getElementById('cfg-ph-max').value = c.ph_max;
        if (c.planta_id) {
            const planta = CATALOGO_PLANTAS.find(p => p.id === c.planta_id);
            if (planta) {
                plantaSeleccionadaId = c.planta_id;
                document.getElementById('plantSelectedName').textContent = planta.nombre;
                document.getElementById('plantSelectedBadge').style.display = 'flex';
                return;
            }
        }
    } else {
        document.getElementById('cfg-temp-min').value = 15;
        document.getElementById('cfg-temp-max').value = 30;
        document.getElementById('cfg-hum-min').value = 40;
        document.getElementById('cfg-hum-max').value = 80;
        document.getElementById('cfg-ph-min').value = 5.5;
        document.getElementById('cfg-ph-max').value = 7.5;
    }
    plantaSeleccionadaId = null;
    document.getElementById('plantSelectedBadge').style.display = 'none';
}

(function loadConfig() {
    loadConfigForCurrentMaceta();
})();

// ============================================================
// RECOMENDACIONES DE PLANTAS POR INVERNADERO
// ============================================================

function showRecommendations() {
    const container = document.getElementById('plantRecommendations');
    const list = document.getElementById('plantRecList');
    if (!container || !list) return;

    const otherMacetas = [];
    for (let m = 1; m <= CONFIG.MACETAS_POR_INV; m++) {
        if (m === currentMaceta) continue;
        const key = `huerto_config_inv${currentInv + 1}_mac${m}`;
        const saved = localStorage.getItem(key);
        if (saved) {
            const c = JSON.parse(saved);
            if (c.planta_id) {
                const planta = CATALOGO_PLANTAS.find(p => p.id === c.planta_id);
                if (planta) {
                    otherMacetas.push({
                        maceta: m,
                        planta: planta,
                        temp_min: c.temp_min !== undefined ? c.temp_min : planta.temp_min,
                        temp_max: c.temp_max !== undefined ? c.temp_max : planta.temp_max
                    });
                }
            }
        }
    }

    if (otherMacetas.length === 0) {
        container.style.display = 'none';
        return;
    }

    const avgTempMin = otherMacetas.reduce((s, m) => s + m.temp_min, 0) / otherMacetas.length;
    const avgTempMax = otherMacetas.reduce((s, m) => s + m.temp_max, 0) / otherMacetas.length;
    const otherPlantIds = new Set(otherMacetas.map(m => m.planta.id));

    const scored = CATALOGO_PLANTAS
        .filter(p => !otherPlantIds.has(p.id))
        .map(p => {
            const overlapMin = Math.max(p.temp_min, avgTempMin);
            const overlapMax = Math.min(p.temp_max, avgTempMax);
            const overlap = Math.max(0, overlapMax - overlapMin);
            const rangeSize = Math.max(p.temp_max - p.temp_min, 1);
            const score = overlap / rangeSize;
            return { ...p, score, overlap };
        })
        .filter(p => p.score > 0.3)
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);

    if (scored.length === 0) {
        container.style.display = 'none';
        return;
    }

    const othersInfo = otherMacetas.map(m =>
        `MAC-${String(m.maceta).padStart(2, '0')}: ${m.planta.nombre} (${m.temp_min}-${m.temp_max}°C)`
    ).join(', ');

    list.innerHTML = `
        <div class="plant-rec-others" style="padding:4px 10px;font-size:9px;color:var(--text-muted);font-family:'JetBrains Mono',monospace;letter-spacing:0.5px;border-bottom:1px solid #222;">
            Ya configuradas: ${othersInfo}
        </div>
        ${scored.map(p => {
            const matchPct = Math.round(p.score * 100);
            const matchClass = matchPct >= 80 ? 'high' : 'med';
            return `
                <div class="plant-rec-item" onclick="seleccionarPlanta(${p.id})">
                    <span class="material-icons-round">eco</span>
                    <span class="plant-rec-name">${p.nombre}</span>
                    <span class="plant-rec-range">${p.temp_min}-${p.temp_max}°C</span>
                    <span class="plant-rec-match ${matchClass}">${matchPct}%</span>
                </div>
            `;
        }).join('')}
    `;

    container.style.display = 'block';
}

// ============================================================
// MODAL DETALLE SENSOR - CLICK EN TARJETA
// ============================================================

let sensorChart = null;
let sensorModalData = [];

const SENSOR_CONFIG = {
    temp:     { icon: 'thermostat',             label: 'Temperatura',      unit: '°C',  color: '#ef4444', key: 'temp' },
    hum_amb:  { icon: 'water_drop',             label: 'Humedad Ambiente', unit: '%',   color: '#06b6d4', key: 'hum_amb' },
    hum_suelo:{ icon: 'grass',                  label: 'Humedad Suelo',    unit: '%',   color: '#22c55e', key: 'hum_suelo' },
    ph:       { icon: 'science',                label: 'pH Suelo',         unit: 'pH',  color: '#a855f7', key: 'ph' }
};

function initSensorModals() {
    const cards = document.querySelectorAll('.sensor-card');
    cards.forEach(card => {
        card.addEventListener('click', () => {
            const tipo = card.dataset.sensor;
            if (tipo && SENSOR_CONFIG[tipo]) abrirSensorModal(tipo);
        });
    });

    const closeBtn = document.getElementById('sensorModalClose');
    const modal = document.getElementById('sensorModal');
    if (closeBtn) closeBtn.addEventListener('click', () => modal.classList.remove('active'));
    if (modal) modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.remove('active'); });

    document.getElementById('sensorTabTabla').addEventListener('click', () => switchSensorView('tabla'));
    document.getElementById('sensorTabGrafico').addEventListener('click', () => switchSensorView('grafico'));
}

function switchSensorView(view) {
    document.getElementById('sensorTabTabla').classList.toggle('active', view === 'tabla');
    document.getElementById('sensorTabGrafico').classList.toggle('active', view === 'grafico');
    document.getElementById('sensorTablaView').style.display = view === 'tabla' ? 'block' : 'none';
    document.getElementById('sensorGraficoView').style.display = view === 'grafico' ? 'block' : 'none';
    if (view === 'grafico' && sensorChart) sensorChart.update();
}

function getSensorEstado(valor, tipo) {
    const U = CONFIG.UMBRALES || {};
    if (tipo === 'temp') {
        const mn = U.temp_min || 15, mx = U.temp_max || 30;
        if (valor < mn || valor > mx) return valor < mn - 3 || valor > mx + 3 ? 'danger' : 'alert';
    } else if (tipo === 'hum_suelo') {
        const mn = U.hum_suelo_min || 40, mx = U.hum_suelo_max || 80;
        if (valor < mn || valor > mx) return valor < mn - 10 || valor > mx + 10 ? 'danger' : 'alert';
    } else if (tipo === 'ph') {
        const mn = U.ph_min || 5.5, mx = U.ph_max || 7.5;
        if (valor < mn || valor > mx) return valor < mn - 0.5 || valor > mx + 0.5 ? 'danger' : 'alert';
    } else if (tipo === 'hum_amb') {
        if (valor < 30 || valor > 85) return valor < 20 || valor > 90 ? 'danger' : 'alert';
    }
    return 'ok';
}

async function abrirSensorModal(tipo) {
    const cfg = SENSOR_CONFIG[tipo];
    const dispositivoId = currentInv + 1;
    const ids = CONFIG.getSensoresMaceta(dispositivoId, currentMaceta);
    const sensorId = ids[cfg.key];

    document.getElementById('sensorModalIcon').textContent = cfg.icon;
    document.getElementById('sensorModalTitle').textContent = cfg.label + ' - Maceta ' + currentMaceta;
    document.getElementById('sensorTablaCol').textContent = cfg.label + ' (' + cfg.unit + ')';
    document.getElementById('sensorModal').classList.add('active');
    switchSensorView('tabla');

    const lecturas = await SupabaseClient.query('monitoreo_lecturas',
        `sensor_id=eq.${sensorId}&order=fecha_hora.desc&limit=100`
    );

    sensorModalData = (lecturas || []).reverse();
    renderSensorTabla(sensorModalData, cfg);
    renderSensorGrafico(sensorModalData, cfg);
    renderSensorStats(sensorModalData, cfg);
}

function renderSensorTabla(data, cfg) {
    const tbody = document.getElementById('sensorTablaBody');
    tbody.innerHTML = '';
    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:var(--text-secondary);">Sin datos</td></tr>';
        return;
    }
    data.forEach(l => {
        const estado = getSensorEstado(l.valor_lectura, cfg.key);
        const fecha = new Date(l.fecha_hora);
        const ts = fecha.toLocaleString('es-PE', { month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit', second:'2-digit', timeZone:'America/Lima' });
        const estadoLabel = estado === 'ok' ? 'Estable' : estado === 'alert' ? 'Alerta' : 'Peligro';
        tbody.innerHTML += `<tr class="row-${estado}">
            <td>${ts}</td>
            <td>${l.valor_lectura.toFixed(cfg.key === 'ph' ? 2 : 1)} ${cfg.unit}</td>
            <td><span class="sensor-estado-badge ${estado}">${estadoLabel}</span></td>
        </tr>`;
    });
}

function renderSensorGrafico(data, cfg) {
    const ctx = document.getElementById('sensorChart');
    if (sensorChart) sensorChart.destroy();

    const labels = data.map(l => {
        const d = new Date(l.fecha_hora);
        return d.toLocaleTimeString('es-PE', { hour:'2-digit', minute:'2-digit', timeZone:'America/Lima' });
    });
    const values = data.map(l => l.valor_lectura);

    const bgColors = data.map(l => {
        const e = getSensorEstado(l.valor_lectura, cfg.key);
        return e === 'ok' ? 'rgba(34,197,94,0.15)' : e === 'alert' ? 'rgba(245,158,11,0.2)' : 'rgba(239,68,68,0.25)';
    });

    const U = CONFIG.UMBRALES || {};
    const limitMin = cfg.key === 'temp' ? U.temp_min : cfg.key === 'hum_suelo' ? U.hum_suelo_min : cfg.key === 'ph' ? U.ph_min : 30;
    const limitMax = cfg.key === 'temp' ? U.temp_max : cfg.key === 'hum_suelo' ? U.hum_suelo_max : cfg.key === 'ph' ? U.ph_max : 85;

    sensorChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: cfg.label,
                data: values,
                borderColor: cfg.color,
                backgroundColor: bgColors,
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: data.map(l => {
                    const e = getSensorEstado(l.valor_lectura, cfg.key);
                    return e === 'ok' ? '#22c55e' : e === 'alert' ? '#f59e0b' : '#ef4444';
                }),
                pointBorderColor: data.map(l => {
                    const e = getSensorEstado(l.valor_lectura, cfg.key);
                    return e === 'ok' ? '#22c55e' : e === 'alert' ? '#f59e0b' : '#ef4444';
                }),
                fill: true,
                tension: 0.3
            }, {
                label: 'Min',
                data: Array(labels.length).fill(limitMin),
                borderColor: 'rgba(245,158,11,0.5)',
                borderWidth: 1,
                borderDash: [5, 5],
                pointRadius: 0,
                fill: false
            }, {
                label: 'Max',
                data: Array(labels.length).fill(limitMax),
                borderColor: 'rgba(239,68,68,0.5)',
                borderWidth: 1,
                borderDash: [5, 5],
                pointRadius: 0,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: true, labels: { color: '#aaa', font: { family: 'JetBrains Mono', size: 10 } } },
                tooltip: {
                    callbacks: {
                        label: (ctx) => ctx.dataset.label + ': ' + (ctx.parsed.y !== null ? ctx.parsed.y.toFixed(cfg.key === 'ph' ? 2 : 1) : '-') + ' ' + cfg.unit
                    }
                }
            },
            scales: {
                x: { ticks: { color: '#666', font: { family: 'JetBrains Mono', size: 9 }, maxRotation: 45 }, grid: { color: '#1a1a1a' } },
                y: { ticks: { color: '#666', font: { family: 'JetBrains Mono', size: 9 } }, grid: { color: '#1a1a1a' } }
            }
        }
    });
}

function renderSensorStats(data, cfg) {
    const container = document.getElementById('sensorStats');
    if (data.length === 0) { container.innerHTML = ''; return; }
    const vals = data.map(l => l.valor_lectura);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
    const alertCount = data.filter(l => getSensorEstado(l.valor_lectura, cfg.key) !== 'ok').length;
    const okCount = data.length - alertCount;

    container.innerHTML = `
        <div class="sensor-stat-item"><div class="stat-dot ok"></div>Min: ${min.toFixed(cfg.key === 'ph' ? 2 : 1)}${cfg.unit}</div>
        <div class="sensor-stat-item"><div class="stat-dot alert"></div>Max: ${max.toFixed(cfg.key === 'ph' ? 2 : 1)}${cfg.unit}</div>
        <div class="sensor-stat-item"><div class="stat-dot ok"></div>Prom: ${avg.toFixed(cfg.key === 'ph' ? 2 : 1)}${cfg.unit}</div>
        <div class="sensor-stat-item"><div class="stat-dot ok"></div>Estables: ${okCount}</div>
        <div class="sensor-stat-item"><div class="stat-dot danger"></div>Alertas: ${alertCount}</div>
    `;
}

// ============================================================
// MODO SIMULACION - LAZO CERRADO
// ============================================================

let overrideTimer = null;
let overrideStartTime = 0;
const OVERRIDE_DURATION = 60000; // 60 segundos para estabilizar

/**
 * Enviar alerta de simulacion al ESP32 via Supabase
 * @param {string} tipoAlerta - Tipo de alerta (sequia, ph_bajo, ph_alto, temp_alta, hum_baja)
 * @param {string} sensorTipo - Tipo de sensor (hum_suelo, ph, temp, hum_amb)
 * @param {number} valorForzado - Valor critico a forzar
 */
async function enviarAlerta(tipoAlerta, sensorTipo, valorForzado) {
    const maceta = currentMaceta;
    const dispositivoId = currentInv + 1;
    
    console.log(`[SIM] Enviando alerta: ${tipoAlerta} -> ${sensorTipo} = ${valorForzado} (MAC-${maceta}, DEV-${dispositivoId})`);
    console.log(`[SIM] SupabaseClient defined:`, typeof SupabaseClient);
    console.log(`[SIM] insert method:`, typeof SupabaseClient.insert);
    
    try {
        // Insertar en tabla simulacion_alertas via Supabase REST
        const result = await SupabaseClient.insert('simulacion_alertas', {
            tipo_alerta: tipoAlerta,
            sensor_tipo: sensorTipo,
            valor_forzado: valorForzado,
            maceta_numero: maceta,
            dispositivo_id: dispositivoId,
            activa: true
        });
        
        if (result) {
            // Mostrar indicador visual
            mostrarOverrideStatus(tipoAlerta, sensorTipo, valorForzado);
            
            // Cambiar color de la tarjeta del sensor afectado
            resaltarSensor(sensorTipo, true);
            
            console.log(`[SIM] Alerta enviada exitosamente`);
        } else {
            console.error(`[SIM] Error al enviar alerta`);
        }
    } catch (error) {
        console.error('[SIM] Error:', error);
    }
}

/**
 * Mostrar indicador de override activo con barra de progreso
 */
function mostrarOverrideStatus(tipoAlerta, sensorTipo, valorForzado) {
    const statusDiv = document.getElementById('overrideStatus');
    const infoSpan = document.getElementById('overrideInfo');
    const progressBar = document.getElementById('overrideProgressBar');
    
    const labels = {
        'sequia': 'SEQUIA - Humedad Suelo',
        'ph_bajo': 'pH BAJO',
        'ph_alto': 'pH ALTO',
        'temp_alta': 'TEMPERATURA ALTA',
        'hum_baja': 'HUMEDAD AMBIENTE BAJA'
    };
    
    infoSpan.textContent = `${labels[tipoAlerta]} -> ${valorForzado}`;
    statusDiv.style.display = 'flex';
    
    const btnMap = {
        'sequia': 'btn-sim-sequia',
        'ph_bajo': 'btn-sim-phbajo',
        'ph_alto': 'btn-sim-phalto',
        'temp_alta': 'btn-sim-phalt',
        'hum_baja': 'btn-sim-humbaja'
    };
    
    const btn = document.getElementById(btnMap[tipoAlerta]);
    if (btn) btn.classList.add('sim-active');
    
    overrideStartTime = Date.now();
    if (overrideTimer) clearInterval(overrideTimer);
    
    overrideTimer = setInterval(() => {
        const elapsed = Date.now() - overrideStartTime;
        const progress = Math.min((elapsed / OVERRIDE_DURATION) * 100, 100);
        progressBar.style.width = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(overrideTimer);
            ocultarOverrideStatus();
            resaltarSensor(sensorTipo, false);
            if (btn) btn.classList.remove('sim-active');
        }
    }, 100);
}

/**
 * Ocultar indicador de override
 */
function ocultarOverrideStatus() {
    const statusDiv = document.getElementById('overrideStatus');
    const progressBar = document.getElementById('overrideProgressBar');
    
    statusDiv.style.display = 'none';
    statusDiv.classList.remove('pulse-animation');
    progressBar.style.width = '0%';
    
    if (overrideTimer) {
        clearInterval(overrideTimer);
        overrideTimer = null;
    }
}

/**
 * Resaltar tarjeta de sensor con color de override
 */
function resaltarSensor(sensorTipo, activar) {
    const cards = document.querySelectorAll('.sensor-card');
    cards.forEach(card => {
        if (card.dataset.sensor === sensorTipo) {
            if (activar) {
                card.classList.add('sensor-override');
            } else {
                card.classList.remove('sensor-override');
            }
        }
    });
}

// ============================================================
// SKELETON LOADING
// ============================================================

function setSkeletonActive(active) {
    document.querySelectorAll('.sensor-card').forEach(card => {
        card.classList.toggle('skeleton', active);
    });
}

// ============================================================
// TOOLTIP EN CARDS
// ============================================================

const SENSOR_RANGES = {
    temp:       { label: 'Temperatura', unit: '°C', min: () => getThreshold('temp_min', 15), max: () => getThreshold('temp_max', 30) },
    hum_amb:    { label: 'Humedad Amb', unit: '%',  min: () => getThreshold('hum_ambiente_min', 30), max: () => getThreshold('hum_ambiente_max', 75) },
    hum_suelo:  { label: 'Humedad Suelo', unit: '%', min: () => getThreshold('hum_suelo_min', 40), max: () => getThreshold('hum_suelo_max', 80) },
    ph:         { label: 'pH Suelo', unit: 'pH', min: () => getThreshold('ph_min', 5.5), max: () => getThreshold('ph_max', 7.5) }
};

function getThreshold(key, fallback) {
    const macetaKey = getConfigKey();
    const saved = localStorage.getItem(macetaKey);
    if (saved) {
        const c = JSON.parse(saved);
        if (c[key] !== undefined) return c[key];
    }
    return fallback;
}

function initTooltips() {
    document.querySelectorAll('.sensor-card').forEach(card => {
        const sensorKey = card.dataset.sensor;
        if (!sensorKey || !SENSOR_RANGES[sensorKey]) return;

        let tip = card.querySelector('.sensor-tooltip');
        if (!tip) {
            tip = document.createElement('div');
            tip.className = 'sensor-tooltip';
            card.appendChild(tip);
        }

        const info = SENSOR_RANGES[sensorKey];
        const valEl = card.querySelector('.value');
        const val = valEl ? valEl.textContent : '--';
        const min = info.min();
        const max = info.max();

        let status = '';
        if (val !== '--' && val !== '-') {
            const numVal = parseFloat(val);
            if (numVal < min || numVal > max) status = 'crit';
            else if (numVal < min * 1.1 || numVal > max * 0.9) status = 'warn';
        }

        tip.innerHTML = `
            <div class="sensor-tooltip-row">
                <span class="sensor-tooltip-label">Rango</span>
                <span class="sensor-tooltip-val">${min} - ${max} ${info.unit}</span>
            </div>
            <div class="sensor-tooltip-row">
                <span class="sensor-tooltip-label">Actual</span>
                <span class="sensor-tooltip-val ${status}">${val} ${info.unit}</span>
            </div>
        `;
    });
}

// ============================================================
// TAB TRANSITION
// ============================================================

function selectInvernadero(index) {
    const content = document.querySelector('.main-content');
    content.classList.add('tab-exit');

    setTimeout(() => {
        currentInv = index;
        currentMaceta = 1;

        document.querySelectorAll('.inv-tab').forEach((tab) => {
            const tabIndex = parseInt(tab.getAttribute('data-inv'));
            tab.classList.toggle('active', tabIndex === index);
        });

        initMacetaTabs();
        loadConfigForCurrentMaceta();
        setSkeletonActive(true);
        cargarDatos().then(() => {
            setSkeletonActive(false);
            initTooltips();
        });
        cargarHistorico();
        iniciarRealtime();

        content.classList.remove('tab-exit');
    }, 250);
}

// ============================================================
// DARK AMBIENT PARTICLES
// ============================================================

(function initParticles() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let particles = [];
    let w, h;

    function resize() {
        w = canvas.width = window.innerWidth;
        h = canvas.height = window.innerHeight;
    }

    function createParticle() {
        const size = Math.random() * 2 + 0.5;
        return {
            x: Math.random() * w,
            y: -10,
            size,
            speedY: Math.random() * 0.3 + 0.1,
            speedX: (Math.random() - 0.5) * 0.15,
            opacity: Math.random() * 0.15 + 0.03,
            wobble: Math.random() * Math.PI * 2,
            wobbleSpeed: Math.random() * 0.005 + 0.002,
            type: Math.random() > 0.7 ? 'leaf' : 'dust'
        };
    }

    function drawLeaf(p) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.wobble);
        ctx.fillStyle = `rgba(34, 120, 50, ${p.opacity})`;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size * 2, p.size, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }

    function drawDust(p) {
        ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity * 0.6})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
    }

    function loop() {
        ctx.clearRect(0, 0, w, h);

        if (particles.length < 30 && Math.random() < 0.05) {
            particles.push(createParticle());
        }

        particles.forEach(p => {
            p.wobble += p.wobbleSpeed;
            p.x += p.speedX + Math.sin(p.wobble) * 0.3;
            p.y += p.speedY;

            if (p.type === 'leaf') drawLeaf(p);
            else drawDust(p);
        });

        particles = particles.filter(p => p.y < h + 10);
        requestAnimationFrame(loop);
    }

    resize();
    window.addEventListener('resize', resize);
    loop();
})();
